The following developers contributed to this project:

* Tuomas Venhola
* Sathish Kumar
* Arsalan Shah
* Shaf Brady Hussain
* Softaculous Team
* Michael Zülsdorff
* Bishop Gregory Godsey (https://github.com/bishopgodsey)
* Roberto Vaccaro (https://github.com/robertito13)
* Huck Jones (https://github.com/huckleberrypie)
* TheGameHHH (https://github.com/TheGameHHH)
* Julien Jehannet (https://github.com/jjehannet)
* Tomáš Votruba (https://github.com/TomasVotruba)
* Eric F. (https://www.opensource-socialnetwork.org/u/ctlui)
* Kevin Breen (https://github.com/kevthehermit)
* Muh Arief Ikhsan Yafi (https://web.facebook.com/muharief.iy)
* James Chang(https://www.opensource-socialnetwork.org/u/zuyan)