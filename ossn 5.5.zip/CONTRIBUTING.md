## DISCLAIMERS

[Guidelines](https://github.com/opensource-socialnetwork/opensource-socialnetwork/wiki/How-to-report-a-issue-on-github)
