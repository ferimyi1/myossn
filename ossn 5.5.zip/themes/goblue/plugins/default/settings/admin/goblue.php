<?php
echo ossn_view_form('goblue/settings', array(
    'action' => ossn_site_url() . 'action/goblue/settings',
	'class' => 'goblue-form-admin',	
));

